
function calcularDelta(a, b, c) {
    return b * b - 4 * a * c;
  }
  
  
  function calcularRaizes(a, b, delta) {
    if (delta < 0) return "Sem raízes reais";
    let x1 = (-b + Math.sqrt(delta)) / (2 * a);
    let x2 = (-b - Math.sqrt(delta)) / (2 * a);
    return { x1, x2 };
  }
  

  function calcularVertice(a, b, c) {
    let xv = -b / (2 * a);
    let yv = a * xv * xv + b * xv + c;
    return { xv, yv };
  }
  
  
  function gerarPontos(a, b, c) {
    let xValues = [];
    let yValues = [];
    for (let x = -100; x <= 100; x += 0.5) {
      xValues.push(x);
      let y = a * x * x + b * x + c;
      yValues.push(y);
    }
    return { xValues, yValues };
  }
  
  let chart = null;
  
  
  function criarGrafico(xValues, yValues) {
    const ctx = document.getElementById("grafico").getContext("2d");
  
    
    if (chart !== null) {
      chart.destroy();
    }
  
    chart = new Chart(ctx, {
        type: "line",
        data: {
          labels: xValues,
          datasets: [{
            label: "Parábola",
            data: yValues,
            borderColor: "red",
            backgroundColor: "pink",
            fill: false,
            tension: 0.1
          }]
        },
        options: {
          responsive: true,
          scales: {
            x: {
              title: { display: true, text: 'X' },
              min: -20,    
              max: 20,     
              ticks: {
                stepSize: 1 
              },
              grid: {
                color: '#ccc',
                zeroLineColor: 'black',
                drawTicks: true
              }
            },
            y: {
              title: { display: true, text: 'Y' },
              min: -50,    
              max: 50,     
              ticks: {
                stepSize: 5 
              },
              grid: {
                color: '#ccc',
                zeroLineColor: 'black',
                drawTicks: true
              }
            }
          }
        }
      });
    }       
  
  
  function calcularFuncao() {
    let a = parseFloat(document.getElementById("coefA").value);
    let b = parseFloat(document.getElementById("coefB").value);
    let c = parseFloat(document.getElementById("coefC").value);
  
    if (a === 0 || isNaN(a) || isNaN(b) || isNaN(c)) {
      alert("Insira valores válidos e o coeficiente 'a' deve ser diferente de 0.");
      return;
    }
  
    let delta = calcularDelta(a, b, c);
    let raizes = calcularRaizes(a, b, delta);
    let vertice = calcularVertice(a, b, c);
    let pontos = gerarPontos(a, b, c);
  
    document.getElementById("delta").innerText = "Δ (Delta): " + delta.toFixed(2);
    document.getElementById("raizes").innerText = (typeof raizes === "string")
      ? raizes
      : `Raízes: x₁ = ${raizes.x1.toFixed(2)}, x₂ = ${raizes.x2.toFixed(2)}`;
    document.getElementById("vertice").innerText = `Vértice: (${vertice.xv.toFixed(2)}, ${vertice.yv.toFixed(2)})`;
  
    criarGrafico(pontos.xValues, pontos.yValues);
  }
  